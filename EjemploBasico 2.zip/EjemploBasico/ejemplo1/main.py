from ejemplo1.money_model import MoneyModel
import matplotlib.pyplot as plt


def basic_example():

    model = MoneyModel(10)
    for i in range(10):
        model.step()
        print("\n")

   
