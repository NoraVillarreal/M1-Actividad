from ejemplo1.main import basic_example
from ejemplo2_add_space.main import basic_example_space

if __name__ == "__main__":
    # basic_example()
    basic_example_space()
